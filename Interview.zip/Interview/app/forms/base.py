from wtforms.validators import DataRequired as WTFDataRrequired


class DataRequired(WTFDataRrequired):
    """
        重写默认的WTF DataRequired，实现自定义message
    """

    def __call__(self, form, field):
        if self.message is None:
            field_text = field.label.text
            self.message = field_text + '不能为空，请填写' + field_text
        super(DataRequired, self).__call__(form, field)
