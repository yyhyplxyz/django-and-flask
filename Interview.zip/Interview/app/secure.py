# -*- coding: utf-8 -*-
__author__ = 'yyh'

SQLALCHEMY_DATABASE_URI = 'mysql+cymysql://root:Yyh9801022007@localhost/Interview'

SECRET_KEY = '\x88D\xf09\x91\x07\x98\x89\x87\x96\xa0A\xc68\xf9\xecJ:U\x17\xc5V\xbe\x8b\xef\xd7\xd8\xd3\xe6\x98*4'


# Email 配置
MAIL_SERVER = 'smtp.qq.com'
MAIL_PORT = 465
MAIL_USE_SSL = True
MAIL_USE_TSL = False
MAIL_USERNAME = '826385871@qq.com '
MAIL_PASSWORD = 'bpzlxvvzzrktbdjf'
MAIL_SUBJECT_PREFIX = '[个人信息系统]'
MAIL_SENDER = '杨元昊'


from datetime import timedelta
REMEMBER_COOKIE_DURATION = timedelta(days=1)





