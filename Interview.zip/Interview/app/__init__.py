from flask import Flask
from flask_login import LoginManager

from app.models.base import db
from app.libs.email import mail
from flask_cache import Cache

__author__ = 'yyh'

login_manager = LoginManager()
cache = Cache(config={'CACHE_TYPE': 'simple'})


def register_web_blueprint(app):
    from app.web import web
    app.register_blueprint(web)


def create_app():
    app = Flask(__name__)

    app.config.from_object('app.secure')

    # 注册SQLAlchemy
    db.init_app(app)

    # 注册email模块
    mail.init_app(app)

    # 注册login模块
    login_manager.init_app(app)
    login_manager.login_view = 'web.login' #自动跳转未登录页面
    login_manager.login_message = '请先登录或注册'

    # 注册flask-cache模块
    cache.init_app(app)

    #注册蓝图
    register_web_blueprint(app)

    return app
